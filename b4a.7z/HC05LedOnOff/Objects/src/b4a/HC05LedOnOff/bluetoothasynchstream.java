package b4a.HC05LedOnOff;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class bluetoothasynchstream extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "b4a.HC05LedOnOff.bluetoothasynchstream");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", b4a.HC05LedOnOff.bluetoothasynchstream.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.Serial.BluetoothAdmin _admin = null;
public anywheresoftware.b4a.randomaccessfile.AsyncStreams _astreams = null;
public anywheresoftware.b4a.objects.Serial _serial = null;
public anywheresoftware.b4a.phone.Phone _ph = null;
public Object _mparent = null;
public String _meventname = "";
public anywheresoftware.b4a.objects.LabelWrapper _lblstatus = null;
public anywheresoftware.b4a.objects.ProgressBarWrapper _progressbar1 = null;
public String _genericdevicename = "";
public String _devicename = "";
public boolean _bluetoothstate = false;
public boolean _connectionstate = false;
public boolean _devicefound = false;
public String _devicemacadress = "";
public String _charset = "";
public anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
public String _state = "";
public b4a.HC05LedOnOff.main _main = null;
public b4a.HC05LedOnOff.starter _starter = null;
public String  _admin_devicefound(String _name,String _macaddress) throws Exception{
 //BA.debugLineNum = 69;BA.debugLine="Private Sub Admin_DeviceFound (Name As String, Mac";
 //BA.debugLineNum = 70;BA.debugLine="Log(Name & \":\" & MacAddress)";
__c.LogImpl("3851969",_name+":"+_macaddress,0);
 //BA.debugLineNum = 71;BA.debugLine="If Name.Contains(GenericDeviceName) Then";
if (_name.contains(_genericdevicename)) { 
 //BA.debugLineNum = 72;BA.debugLine="Log(GenericDeviceName & \" found\")";
__c.LogImpl("3851971",_genericdevicename+" found",0);
 //BA.debugLineNum = 73;BA.debugLine="DeviceName = Name";
_devicename = _name;
 //BA.debugLineNum = 74;BA.debugLine="DeviceMacAdress = MacAddress";
_devicemacadress = _macaddress;
 //BA.debugLineNum = 78;BA.debugLine="If PH.SdkVersion <= 24 Then";
if (_ph.getSdkVersion()<=24) { 
 //BA.debugLineNum = 79;BA.debugLine="Admin.CancelDiscovery";
_admin.CancelDiscovery();
 //BA.debugLineNum = 80;BA.debugLine="lblStatus.Text = GenericDeviceName & \" found\"";
_lblstatus.setText(BA.ObjectToCharSequence(_genericdevicename+" found"));
 }else {
 //BA.debugLineNum = 82;BA.debugLine="lblStatus.Text = GenericDeviceName & \" found, p";
_lblstatus.setText(BA.ObjectToCharSequence(_genericdevicename+" found, please wait."));
 };
 };
 //BA.debugLineNum = 85;BA.debugLine="End Sub";
return "";
}
public String  _admin_discoveryfinished() throws Exception{
 //BA.debugLineNum = 90;BA.debugLine="Private Sub Admin_DiscoveryFinished";
 //BA.debugLineNum = 91;BA.debugLine="If DeviceName = \"\" Then";
if ((_devicename).equals("")) { 
 //BA.debugLineNum = 92;BA.debugLine="lblStatus.Text = \"Device \" & GenericDeviceName &";
_lblstatus.setText(BA.ObjectToCharSequence("Device "+_genericdevicename+" Not found"));
 }else {
 //BA.debugLineNum = 94;BA.debugLine="lblStatus.Text = \"Connecting to: \" & GenericDevi";
_lblstatus.setText(BA.ObjectToCharSequence("Connecting to: "+_genericdevicename));
 //BA.debugLineNum = 95;BA.debugLine="Serial.Connect(DeviceMacAdress)";
_serial.Connect(ba,_devicemacadress);
 };
 //BA.debugLineNum = 97;BA.debugLine="End Sub";
return "";
}
public String  _admin_statechanged(int _newstate,int _oldstate) throws Exception{
 //BA.debugLineNum = 99;BA.debugLine="Private Sub Admin_StateChanged (NewState As Int, O";
 //BA.debugLineNum = 100;BA.debugLine="Log(\"State changed: \" & NewState)";
__c.LogImpl("3983041","State changed: "+BA.NumberToString(_newstate),0);
 //BA.debugLineNum = 101;BA.debugLine="lblStatus.Text = \"State changed: \" & NewState";
_lblstatus.setText(BA.ObjectToCharSequence("State changed: "+BA.NumberToString(_newstate)));
 //BA.debugLineNum = 102;BA.debugLine="BluetoothState = NewState = Admin.STATE_ON";
_bluetoothstate = _newstate==_admin.STATE_ON;
 //BA.debugLineNum = 103;BA.debugLine="End Sub";
return "";
}
public String  _astreams_error() throws Exception{
 //BA.debugLineNum = 183;BA.debugLine="Private Sub Astreams_Error";
 //BA.debugLineNum = 184;BA.debugLine="Log(\"error: \" & LastException)";
__c.LogImpl("31507329","error: "+BA.ObjectToString(__c.LastException(ba)),0);
 //BA.debugLineNum = 185;BA.debugLine="Astreams.Close";
_astreams.Close();
 //BA.debugLineNum = 186;BA.debugLine="CallSubDelayed(mParent, mEventName & \"_Terminated";
__c.CallSubDelayed(ba,_mparent,_meventname+"_Terminated");
 //BA.debugLineNum = 187;BA.debugLine="End Sub";
return "";
}
public String  _astreams_newdata(byte[] _buffer) throws Exception{
String _s = "";
 //BA.debugLineNum = 143;BA.debugLine="Private Sub Astreams_NewData (Buffer() As Byte)";
 //BA.debugLineNum = 146;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 147;BA.debugLine="sb.Append(BytesToString(Buffer, 0, Buffer.Length,";
_sb.Append(__c.BytesToString(_buffer,(int) (0),_buffer.length,_charset));
 //BA.debugLineNum = 148;BA.debugLine="Dim s As String = sb.ToString";
_s = _sb.ToString();
 //BA.debugLineNum = 152;BA.debugLine="CallSubDelayed2(mParent, mEventName & \"_NewText\",";
__c.CallSubDelayed2(ba,_mparent,_meventname+"_NewText",(Object)(_s));
 //BA.debugLineNum = 177;BA.debugLine="End Sub";
return "";
}
public String  _astreams_terminated() throws Exception{
 //BA.debugLineNum = 179;BA.debugLine="Private Sub Astreams_Terminated";
 //BA.debugLineNum = 180;BA.debugLine="CallSubDelayed(mParent, mEventName & \"_Terminated";
__c.CallSubDelayed(ba,_mparent,_meventname+"_Terminated");
 //BA.debugLineNum = 181;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private Admin As BluetoothAdmin";
_admin = new anywheresoftware.b4a.objects.Serial.BluetoothAdmin();
 //BA.debugLineNum = 8;BA.debugLine="Public Astreams As AsyncStreams";
_astreams = new anywheresoftware.b4a.randomaccessfile.AsyncStreams();
 //BA.debugLineNum = 9;BA.debugLine="Private Serial As Serial";
_serial = new anywheresoftware.b4a.objects.Serial();
 //BA.debugLineNum = 10;BA.debugLine="Private PH As Phone";
_ph = new anywheresoftware.b4a.phone.Phone();
 //BA.debugLineNum = 11;BA.debugLine="Private mParent As Object";
_mparent = new Object();
 //BA.debugLineNum = 12;BA.debugLine="Private mEventName As String";
_meventname = "";
 //BA.debugLineNum = 13;BA.debugLine="Private lblStatus As Label";
_lblstatus = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 14;BA.debugLine="Private ProgressBar1 As ProgressBar";
_progressbar1 = new anywheresoftware.b4a.objects.ProgressBarWrapper();
 //BA.debugLineNum = 16;BA.debugLine="Private GenericDeviceName, DeviceName As String";
_genericdevicename = "";
_devicename = "";
 //BA.debugLineNum = 18;BA.debugLine="Public BluetoothState, ConnectionState, DeviceFou";
_bluetoothstate = false;
_connectionstate = false;
_devicefound = false;
 //BA.debugLineNum = 19;BA.debugLine="Private DeviceName, DeviceMacAdress As String";
_devicename = "";
_devicemacadress = "";
 //BA.debugLineNum = 21;BA.debugLine="Public CharSet = \"UTF-8\" As String";
_charset = "UTF-8";
 //BA.debugLineNum = 22;BA.debugLine="Private sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 23;BA.debugLine="Public State As String";
_state = "";
 //BA.debugLineNum = 24;BA.debugLine="End Sub";
return "";
}
public String  _close() throws Exception{
 //BA.debugLineNum = 189;BA.debugLine="Public Sub Close";
 //BA.debugLineNum = 190;BA.debugLine="Astreams.Close";
_astreams.Close();
 //BA.debugLineNum = 191;BA.debugLine="End Sub";
return "";
}
public String  _connect(String _name) throws Exception{
boolean _success = false;
 //BA.debugLineNum = 52;BA.debugLine="Public Sub Connect(Name As String)";
 //BA.debugLineNum = 53;BA.debugLine="GenericDeviceName = Name";
_genericdevicename = _name;
 //BA.debugLineNum = 54;BA.debugLine="Dim success As Boolean = Admin.StartDiscovery";
_success = _admin.StartDiscovery();
 //BA.debugLineNum = 55;BA.debugLine="If success = False Then";
if (_success==__c.False) { 
 //BA.debugLineNum = 56;BA.debugLine="lblStatus.Text = \"Error starting discovery proce";
_lblstatus.setText(BA.ObjectToCharSequence("Error starting discovery process."));
 }else {
 //BA.debugLineNum = 58;BA.debugLine="lblStatus.Text = \"Start discovery\"";
_lblstatus.setText(BA.ObjectToCharSequence("Start discovery"));
 //BA.debugLineNum = 59;BA.debugLine="ProgressBar1.Visible = True";
_progressbar1.setVisible(__c.True);
 };
 //BA.debugLineNum = 61;BA.debugLine="End Sub";
return "";
}
public String  _disconnect() throws Exception{
 //BA.debugLineNum = 63;BA.debugLine="Public Sub Disconnect";
 //BA.debugLineNum = 64;BA.debugLine="If Astreams.IsInitialized Then Astreams.Close";
if (_astreams.IsInitialized()) { 
_astreams.Close();};
 //BA.debugLineNum = 65;BA.debugLine="If Serial.IsInitialized Then Serial.Disconnect";
if (_serial.IsInitialized()) { 
_serial.Disconnect();};
 //BA.debugLineNum = 66;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,Object _parent,String _eventname,anywheresoftware.b4a.objects.LabelWrapper _statuslabel,anywheresoftware.b4a.objects.ProgressBarWrapper _pgb) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 32;BA.debugLine="Public Sub Initialize(Parent As Object, EventName";
 //BA.debugLineNum = 33;BA.debugLine="mParent = Parent";
_mparent = _parent;
 //BA.debugLineNum = 34;BA.debugLine="mEventName = EventName";
_meventname = _eventname;
 //BA.debugLineNum = 35;BA.debugLine="lblStatus = StatusLabel";
_lblstatus = _statuslabel;
 //BA.debugLineNum = 36;BA.debugLine="Admin.Initialize(\"Admin\")";
_admin.Initialize(ba,"Admin");
 //BA.debugLineNum = 37;BA.debugLine="Serial.Initialize(\"Serial\")";
_serial.Initialize("Serial");
 //BA.debugLineNum = 38;BA.debugLine="ProgressBar1 = Pgb";
_progressbar1 = _pgb;
 //BA.debugLineNum = 39;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 41;BA.debugLine="If Admin.IsEnabled = False Then";
if (_admin.IsEnabled()==__c.False) { 
 //BA.debugLineNum = 42;BA.debugLine="If Admin.Enable = False Then";
if (_admin.Enable()==__c.False) { 
 //BA.debugLineNum = 43;BA.debugLine="ToastMessageShow(\"Error enabling Bluetooth adap";
__c.ToastMessageShow(BA.ObjectToCharSequence("Error enabling Bluetooth adapter."),__c.True);
 }else {
 //BA.debugLineNum = 45;BA.debugLine="ToastMessageShow(\"Enabling Bluetooth adapter...";
__c.ToastMessageShow(BA.ObjectToCharSequence("Enabling Bluetooth adapter..."),__c.False);
 };
 }else {
 //BA.debugLineNum = 48;BA.debugLine="BluetoothState = True";
_bluetoothstate = __c.True;
 };
 //BA.debugLineNum = 50;BA.debugLine="End Sub";
return "";
}
public String  _sendbytes(byte[] _buffer) throws Exception{
 //BA.debugLineNum = 122;BA.debugLine="Public Sub SendBytes(Buffer() As Byte)";
 //BA.debugLineNum = 123;BA.debugLine="Astreams.Write(Buffer)";
_astreams.Write(_buffer);
 //BA.debugLineNum = 124;BA.debugLine="End Sub";
return "";
}
public String  _sendtext(String _text) throws Exception{
 //BA.debugLineNum = 129;BA.debugLine="Public Sub SendText(Text As String)";
 //BA.debugLineNum = 130;BA.debugLine="Astreams.Write(Text.GetBytes(CharSet))";
_astreams.Write(_text.getBytes(_charset));
 //BA.debugLineNum = 131;BA.debugLine="End Sub";
return "";
}
public String  _serial_connected(boolean _success) throws Exception{
String _msg = "";
 //BA.debugLineNum = 106;BA.debugLine="Sub Serial_Connected (Success As Boolean)";
 //BA.debugLineNum = 107;BA.debugLine="Private msg As String";
_msg = "";
 //BA.debugLineNum = 108;BA.debugLine="If Success = True Then";
if (_success==__c.True) { 
 //BA.debugLineNum = 109;BA.debugLine="If Astreams.IsInitialized Then Astreams.Close";
if (_astreams.IsInitialized()) { 
_astreams.Close();};
 //BA.debugLineNum = 110;BA.debugLine="Astreams.Initialize(Serial.InputStream, Serial.O";
_astreams.Initialize(ba,_serial.getInputStream(),_serial.getOutputStream(),"Astreams");
 //BA.debugLineNum = 111;BA.debugLine="msg = \"Connected\"";
_msg = "Connected";
 //BA.debugLineNum = 112;BA.debugLine="ProgressBar1.Visible = False";
_progressbar1.setVisible(__c.False);
 }else {
 //BA.debugLineNum = 114;BA.debugLine="Log(LastException.Message)";
__c.LogImpl("31048584",__c.LastException(ba).getMessage(),0);
 //BA.debugLineNum = 115;BA.debugLine="msg = LastException.Message";
_msg = __c.LastException(ba).getMessage();
 };
 //BA.debugLineNum = 117;BA.debugLine="lblStatus.Text = msg";
_lblstatus.setText(BA.ObjectToCharSequence(_msg));
 //BA.debugLineNum = 118;BA.debugLine="CallSubDelayed2(mParent, mEventName & \"_Connected";
__c.CallSubDelayed2(ba,_mparent,_meventname+"_Connected",(Object)(_success));
 //BA.debugLineNum = 119;BA.debugLine="End Sub";
return "";
}
public String  _writebytes(byte[] _buffer) throws Exception{
 //BA.debugLineNum = 139;BA.debugLine="Public Sub WriteBytes(Buffer() As Byte)";
 //BA.debugLineNum = 140;BA.debugLine="Astreams.Write(Buffer)";
_astreams.Write(_buffer);
 //BA.debugLineNum = 141;BA.debugLine="End Sub";
return "";
}
public String  _writetext(String _text) throws Exception{
 //BA.debugLineNum = 134;BA.debugLine="Public Sub WriteText(Text As String)";
 //BA.debugLineNum = 135;BA.debugLine="Astreams.Write(Text.GetBytes(CharSet))";
_astreams.Write(_text.getBytes(_charset));
 //BA.debugLineNum = 136;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
