#include "B4RDefines.h"

B4R::Serial* b4r_main::_serial1;
B4R::B4RSoftwareSerial* b4r_main::_softwareserial1;
B4R::AsyncStreams* b4r_main::_astream;
B4R::Pin* b4r_main::_yellowled;
B4R::Timer* b4r_main::_timer1;
static B4R::Serial be_gann1_3;
static B4R::B4RSoftwareSerial be_gann2_3;
static B4R::AsyncStreams be_gann3_3;
static B4R::Pin be_gann4_3;
static B4R::Timer be_gann5_3;


 void b4r_main::_appstart(){
const UInt cp = B4R::StackMemory::cp;
 //BA.debugLineNum = 16;BA.debugLine="Private Sub AppStart";
 //BA.debugLineNum = 17;BA.debugLine="Serial1.Initialize(115200)";
b4r_main::_serial1->Initialize((ULong) (115200));
 //BA.debugLineNum = 18;BA.debugLine="Log(\"Arduino板子系統啟動了!!!\")";
B4R::Common::LogHelper(1,102,F("Arduino板子系統啟動了!!!"));
 //BA.debugLineNum = 19;BA.debugLine="YellowLED.Initialize(7, YellowLED.MODE_OUTPUT)";
b4r_main::_yellowled->Initialize((Byte) (7),Pin_MODE_OUTPUT);
 //BA.debugLineNum = 20;BA.debugLine="SoftwareSerial1.Initialize(9600, 8, 9) 'software";
b4r_main::_softwareserial1->Initialize((ULong) (9600),(Byte) (8),(Byte) (9));
 //BA.debugLineNum = 21;BA.debugLine="Astream.Initialize(SoftwareSerial1.Stream, \"astre";
b4r_main::_astream->Initialize(b4r_main::_softwareserial1->getStream(),_astream_newdata,NULL);
 //BA.debugLineNum = 22;BA.debugLine="Timer1.Initialize(\"timer1_Tick\", 1000)";
b4r_main::_timer1->Initialize(_timer1_tick,(ULong) (1000));
 //BA.debugLineNum = 23;BA.debugLine="Timer1.Enabled = True";
b4r_main::_timer1->setEnabled(Common_True);
 //BA.debugLineNum = 24;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}
void b4r_main::_astream_newdata(B4R::Array* _b){
const UInt cp = B4R::StackMemory::cp;
B4R::ByteConverter be_ann30_3;
B4R::ByteConverter* _bc = NULL;
B4R::Object be_ann31_13;
B4R::B4RString be_ann32_13;
B4R::B4RString be_ann35_13;
 //BA.debugLineNum = 50;BA.debugLine="Sub AStream_NewData (b() As Byte)";
 //BA.debugLineNum = 53;BA.debugLine="Dim bc As ByteConverter";
_bc = &be_ann30_3;
 //BA.debugLineNum = 61;BA.debugLine="Log(\"接收字串的第一個位元: \", bc.SubString2(b, 0,1))";
B4R::Common::LogHelper(2,102,F("接收字串的第一個位元: "),100,be_ann31_13.wrapPointer(_bc->SubString2(_b,(UInt) (0),(UInt) (1))));
 //BA.debugLineNum = 63;BA.debugLine="If bc.SubString2(b, 0,1)==\"1\" Then";
if ((_bc->SubString2(_b,(UInt) (0),(UInt) (1)))->equals((be_ann32_13.wrap("1"))->GetBytes())) { 
 //BA.debugLineNum = 64;BA.debugLine="YellowLED.DigitalWrite(True)";
b4r_main::_yellowled->DigitalWrite(Common_True);
 };
 //BA.debugLineNum = 67;BA.debugLine="If bc.SubString2(b, 0,1)==\"0\" Then";
if ((_bc->SubString2(_b,(UInt) (0),(UInt) (1)))->equals((be_ann35_13.wrap("0"))->GetBytes())) { 
 //BA.debugLineNum = 68;BA.debugLine="YellowLED.DigitalWrite(False)";
b4r_main::_yellowled->DigitalWrite(Common_False);
 };
 //BA.debugLineNum = 71;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}

void b4r_main::initializeProcessGlobals() {
     B4R::StackMemory::buffer = (byte*)malloc(STACK_BUFFER_SIZE);
     b4r_main::_process_globals();

   
}
void b4r_main::_process_globals(){
const UInt cp = B4R::StackMemory::cp;
 //BA.debugLineNum = 8;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Public Serial1 As Serial";
b4r_main::_serial1 = &be_gann1_3;
 //BA.debugLineNum = 10;BA.debugLine="Private SoftwareSerial1 As SoftwareSerial";
b4r_main::_softwareserial1 = &be_gann2_3;
 //BA.debugLineNum = 11;BA.debugLine="Private Astream As AsyncStreams";
b4r_main::_astream = &be_gann3_3;
 //BA.debugLineNum = 12;BA.debugLine="Private YellowLED As Pin";
b4r_main::_yellowled = &be_gann4_3;
 //BA.debugLineNum = 13;BA.debugLine="Private Timer1 As Timer";
b4r_main::_timer1 = &be_gann5_3;
 //BA.debugLineNum = 14;BA.debugLine="End Sub";
}
void b4r_main::_timer1_tick(){
const UInt cp = B4R::StackMemory::cp;
bool _c1 = false;
B4R::B4RString* _str1 = B4R::B4RString::EMPTY;
B4R::B4RString be_ann21_2;
B4R::B4RString be_ann24_2;
 //BA.debugLineNum = 26;BA.debugLine="Sub Timer1_Tick";
 //BA.debugLineNum = 31;BA.debugLine="Dim c1 As Boolean";
_c1 = false;
 //BA.debugLineNum = 32;BA.debugLine="Dim str1 As String";
_str1 = B4R::B4RString::EMPTY;
 //BA.debugLineNum = 35;BA.debugLine="c1=YellowLED.DigitalRead";
_c1 = b4r_main::_yellowled->DigitalRead();
 //BA.debugLineNum = 36;BA.debugLine="If c1==True Then";
if (_c1==Common_True) { 
 //BA.debugLineNum = 38;BA.debugLine="str1=\"1\"";
_str1 = be_ann21_2.wrap("1");
 //BA.debugLineNum = 39;BA.debugLine="Astream.Write(str1.GetBytes   )";
b4r_main::_astream->Write(_str1->GetBytes());
 }else {
 //BA.debugLineNum = 41;BA.debugLine="str1=\"0\"";
_str1 = be_ann24_2.wrap("0");
 //BA.debugLineNum = 42;BA.debugLine="Astream.Write(str1.GetBytes  )";
b4r_main::_astream->Write(_str1->GetBytes());
 };
 //BA.debugLineNum = 47;BA.debugLine="Log(\"YellowLED.DigitalRead: \", c1)";
B4R::Common::LogHelper(2,102,F("YellowLED.DigitalRead: "),8,_c1);
 //BA.debugLineNum = 48;BA.debugLine="End Sub";
B4R::StackMemory::cp = cp;
}
