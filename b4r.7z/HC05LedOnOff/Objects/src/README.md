#rSoftwareSerial

SoftwareSerial library. Adds software based serial ports.

Further information: https://www.b4x.com/search?product=B4R&query=SoftwareSerial

B4R: https://www.b4x.com/b4r.html