
#ifndef b4r_main_h
#define b4r_main_h

class b4r_main {
public:

static void initializeProcessGlobals();
static void _appstart();
static void _astream_newdata(B4R::Array* _b);
static void _process_globals();
static B4R::Serial* _serial1;
static B4R::B4RSoftwareSerial* _softwareserial1;
static B4R::AsyncStreams* _astream;
static B4R::Pin* _yellowled;
static B4R::Timer* _timer1;
static void _timer1_tick();
};

#endif